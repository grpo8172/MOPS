# Define the path of the output file
output_file_path = 'output.txt'

# Define the path of the result output file
result_file_path = 'result_output.txt'

# Open the file in read mode
with open(output_file_path, 'r') as file:
    # Read all lines from the file
    lines = file.readlines()

# Initialize a list to store the results
results = []

# Iterate over each line
for line in lines:
    # Strip the leading and trailing whitespaces
    line = line.strip()
    
    # Check if the line starts with "TASK"
    if line.startswith("TASK"):
        # Store the task name
        task_name = line.split("[", 1)[1].rsplit("]", 1)[0].strip()
    
    # Check if the line starts with "ok", "changed", or "failed"
    elif any(line.startswith(status) for status in ["ok", "changed", "failed"]):
        # Determine the status of the task
        status = "Pass" if "failed" not in line else "Fail"
        
        # Append the task name and status to the results
        results.append(f"{task_name}: {status}")

# Write the results to the result_output.txt file
with open(result_file_path, 'w') as result_file:
    for result in results:
        result_file.write(result + '\n')

print(f"Results have been written to {result_file_path}")

