import re

input_data = """
Context   :sgi_fbb                        Context id  : 0x40080008  
------------------------------------------------------------------
Neighbor     Nexthop-Grid   Minimum    Multiplier  State     Home/        Discriminator           
                           Tx/Rx intvl                      Backup        Local       Remote      
2405:dc00:42:166::2
                34500027    300/1000       3       Up                     0x1701002e  0x10016     
2405:dc00:42:166::3
                34500028    300/1000       3       Up                     0x1701003b  0x1000a     
2405:dc00:42:169::2
                3450002a    300/1000       3       Up                     0x1801001e  0x10010     
2405:dc00:42:169::3
                34500029    300/1000       3       Up                     0x1801003a  0x10007     
2405:dc00:42:16c::2
                3450006c    300/1000       3       Up                     0x1901003b  0x1000b     
2405:dc00:42:16c::3
                3450006d    300/1000       3       Up                     0x1901003a  0x10004     
2405:dc00:42:16f::2
                0           300/1000       3       Admin Down             0x0         0x0         
2405:dc00:42:16f::3
                0           300/1000       3       Admin Down             0x0         0x0         
Context   :sgi_nat                        Context id  : 0x40080009  
------------------------------------------------------------------
Neighbor     Nexthop-Grid   Minimum    Multiplier  State     Home/        Discriminator           
                           Tx/Rx intvl                      Backup        Local       Remote      
2405:dc00:42:165::2
                3450002b    300/1000       3       Up                     0x17010021  0x10018     
2405:dc00:42:165::3
                3450002e    300/1000       3       Up                     0x17010020  0x1000b     
2405:dc00:42:168::2
                3450002c    300/1000       3       Up                     0x1801001f  0x10012     
2405:dc00:42:168::3
                3450002d    300/1000       3       Up                     0x1801003b  0x10008     
2405:dc00:42:16b::2
                3450006e    300/1000       3       Up                     0x1901002b  0x1000d     
2405:dc00:42:16b::3
                3450006f    300/1000       3       Up                     0x1901002a  0x10005     
2405:dc00:42:16e::2
                0           300/1000       3       Admin Down             0x0         0x0         
2405:dc00:42:16e::3
                0           300/1000       3       Admin Down             0x0         0x0         
Context   :sgi_fw                         Context id  : 0x4008000a  
"""

contexts = {}
current_context = ""
lines = input_data.splitlines()

for line in lines:
    if line.startswith("Context"):
        current_context = line.split(":")[1].strip()
    elif re.match(r"\d{4}:", line):
        parts = line.split()
        if len(parts) >= 6:  # Ensure there are at least 6 elements in the list
            ip = parts[0]
            state = parts[5]
            if current_context:
                if current_context not in contexts:
                    contexts[current_context] = []
                contexts[current_context].append({"IP": ip, "State": state})

for context, neighbors in contexts.items():
    print(f"Context: {context}")
    print("Neighbors:")
    for neighbor in neighbors:
        print(f"  IP: {neighbor['IP']}")
        print(f"  State: {neighbor['State']}")

